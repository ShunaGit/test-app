export * from './product.adapter';
