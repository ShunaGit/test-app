export enum SORT_TYPE_ENUM {
  NAME = 'name',
  PRICE = 'price',
  RATING = 'rating'
}
