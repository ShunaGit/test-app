export interface ISortType {
  key: string;
  label: string;
}
